import { Building, Calendar, LayoutGrid } from "lucide-react"

interface FeatureSectionProps {
  icon: "Building" | "Calendar" | "LayoutGrid"
  title: string
  description: string
}

export default function FeatureSection({ icon, title, description }: FeatureSectionProps) {
  const IconComponent = {
    Building,
    Calendar,
    LayoutGrid,
  }[icon]

  return (
    <div className="flex flex-col items-center text-center">
      <div className="mb-4 rounded-full bg-primary/10 p-3">
        <IconComponent className="h-8 w-8 text-primary" />
      </div>
      <h3 className="mb-2 text-xl font-bold">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  )
}
