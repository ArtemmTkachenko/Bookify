"use client"

import { useEffect, useState, useRef } from "react"
import { Calendar, Building2, Settings, CheckCircle } from "lucide-react"

const featureItems = [
  {
    icon: <Building2 className="h-8 w-8 text-primary" />,
    title: "Built for Venue Owners, Not Everyone",
    description:
      "Bookify isn't just another tool—it's made specifically for venue owners. Forget generic booking systems. With Bookify, you get exactly what you need to manage reservations, resources, and daily operations effortlessly.",
    highlights: ["Purpose-built platform", "No generic features", "Venue-focused tools"],
  },
  {
    icon: <Calendar className="h-8 w-8 text-primary" />,
    title: "Real-Time Calendar & Availability",
    description:
      "Stay in control with a live calendar that shows all current and upcoming bookings. Track occupancy rates, spot availability gaps, and make quick, confident decisions without switching tools.",
    highlights: ["Live calendar updates", "Occupancy tracking", "Quick decision making"],
  },
  {
    icon: <Settings className="h-8 w-8 text-primary" />,
    title: "Manage Resources in Seconds",
    description:
      "Rooms, equipment, or venue spaces—Bookify's live Resources page lets you showcase and update it all on the fly. Your team and clients always have access to accurate, up-to-date information.",
    highlights: ["Instant updates", "Real-time sync", "Team collaboration"],
  },
]

export default function Features() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  return (
    <section id="features" ref={sectionRef} className="py-20 bg-gradient-to-br from-gray-50 via-white to-secondary/50">
      <div className="container mx-auto px-4">
        {/* Header Section */}
        <div
          className={`max-w-3xl mx-auto text-center mb-16 transition-all duration-1000 ${
            isVisible ? "opacity-100 animate-scale-in" : "opacity-0"
          }`}
        >
          <div className="inline-flex items-center mb-6 px-4 py-2 rounded-full bg-primary/10 text-sm text-primary border border-primary/20">
            <CheckCircle className="w-4 h-4 mr-2" />
            <span>Everything You Need, Nothing You Don't</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gray-900">
            Powerful Features for
            <span className="text-primary"> Venue Owners</span>
          </h2>
          <p className="text-xl text-gray-600 leading-relaxed">
            Designed specifically for venue management, helping you save time and reduce manual work with intelligent
            automation.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
          {featureItems.map((item, index) => (
            <div
              key={index}
              className={`group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-500 border border-gray-100 hover:border-primary/20 hover:-translate-y-2 ${
                isVisible ? "opacity-100 animate-fade-in" : "opacity-0"
              }`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="bg-primary/10 inline-flex p-4 rounded-xl mb-6 group-hover:bg-primary/20 transition-colors">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">{item.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{item.description}</p>

              <div className="space-y-2">
                {item.highlights.map((highlight, idx) => (
                  <div key={idx} className="flex items-center text-sm text-gray-500">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    {highlight}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div
          className={`bg-white rounded-2xl p-8 md:p-12 shadow-lg border border-gray-100 mb-20 transition-all duration-1000 ${
            isVisible ? "opacity-100 animate-scale-in animate-delay-300" : "opacity-0"
          }`}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="transform transition-transform hover:scale-105 duration-300">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-gray-600">Venues Using Bookify</div>
            </div>
            <div className="transform transition-transform hover:scale-105 duration-300">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">75%</div>
              <div className="text-gray-600">Time Saved on Management</div>
            </div>
            <div className="transform transition-transform hover:scale-105 duration-300">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-gray-600">Real-time Updates</div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div
          className={`relative transition-all duration-1000 ${
            isVisible ? "opacity-100 animate-scale-in animate-delay-500" : "opacity-0"
          }`}
        >
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl p-8 md:p-12 relative overflow-hidden">
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-white/10 blur-3xl rounded-full animate-pulse-slow"></div>
            <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-white/10 blur-3xl rounded-full animate-pulse-slow"></div>

            <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
              <div className="text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold mb-4 text-white">
                  Ready to simplify your venue management?
                </h3>
                <p className="text-white/90 mb-6 md:mb-0 text-lg">
                  Join hundreds of venue owners already using Bookify to streamline their operations.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-white hover:bg-gray-50 text-primary font-semibold px-8 py-4 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1">
                  Sign up now
                </button>
                <button className="border-2 border-white/20 hover:border-white/40 text-white font-medium px-8 py-4 rounded-lg transition-all duration-300 backdrop-blur-sm hover:-translate-y-1">
                  Learn more
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
