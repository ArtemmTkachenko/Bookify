"use client"

import { useEffect, useState, useRef } from "react"
import { ArrowRight, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    setIsVisible(true)

    // Autoplay video when component mounts
    if (videoRef.current) {
      videoRef.current.play().catch((error) => {
        console.error("Video autoplay failed:", error)
      })
    }
  }, [])

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white to-secondary pt-20 pb-20 md:pt-28 md:pb-28">
      {/* Background Elements */}
      <div className="absolute top-20 right-0 w-64 h-64 bg-orange-100 rounded-full blur-3xl animate-pulse-slow"></div>
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse-slow"></div>

      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div
            className={`max-w-2xl transition-all duration-1000 ${isVisible ? "opacity-100 animate-slide-in-left" : "opacity-0 -translate-x-10"}`}
          >
            <div className="inline-flex items-center mb-6 px-4 py-2 rounded-full bg-primary/10 text-sm text-primary border border-primary/20">
              <CheckCircle className="w-4 h-4 mr-2" />
              <span>Purpose-built for venue owners</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-gray-900">
              Simplify Venue Bookings with <span className="text-primary">Bookify</span>
            </h1>

            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              A booking and operations platform built exclusively for venue owners—manage everything, all in one place.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-primary hover:bg-primary/90 text-white px-8 py-6 text-lg font-semibold rounded-lg shadow-lg hover:shadow-primary/30 transition-all duration-300 hover:-translate-y-1">
                Sign up now
              </Button>
              <Button
                variant="outline"
                className="group border-primary/20 hover:border-primary/40 text-primary hover:bg-primary/5 px-8 py-6 text-lg font-medium rounded-lg transition-all duration-300"
              >
                See how it works
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            <div className="mt-8 flex items-center gap-2 text-gray-500">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span>No credit card required</span>
            </div>
          </div>

          <div
            className={`relative transition-all duration-1000 ${isVisible ? "opacity-100 animate-slide-in-right" : "opacity-0 translate-x-10"}`}
          >
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-3xl"></div>
            <div className="relative bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden animate-float">
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-4 flex items-center justify-between">
                <div className="flex items-center">
                  <span className="font-medium">Venue Management Made Easy</span>
                </div>
                <div className="flex space-x-1">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
              </div>
              <div className="aspect-video bg-gray-100 overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  loop
                  muted
                  playsInline
                  poster="/placeholder.svg?height=400&width=600"
                >
                  <source src="/venue-booking-new.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
