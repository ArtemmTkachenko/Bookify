"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CheckCircle } from "lucide-react"

export default function SignupSection() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <section id="signup" ref={sectionRef} className="py-20 bg-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-secondary rounded-full blur-3xl opacity-50"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-100 rounded-full blur-3xl opacity-50"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div
              className={`transition-all duration-1000 ${isVisible ? "opacity-100 animate-slide-in-left" : "opacity-0"}`}
            >
              <div className="inline-flex items-center mb-6 px-4 py-2 rounded-full bg-primary/10 text-sm text-primary border border-primary/20">
                <CheckCircle className="w-4 h-4 mr-2" />
                <span>Get Started Today</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Ready to transform your venue management?
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Join hundreds of venue owners who are already saving time and reducing manual work with Bookify.
              </p>
              <ul className="space-y-3 mb-8">
                {["No credit card required", "Cancel anytime", "Dedicated support"].map((item, index) => (
                  <li key={index} className="flex items-center text-gray-600">
                    <CheckCircle className="h-5 w-5 mr-3 text-green-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div
              className={`bg-white rounded-2xl p-8 shadow-xl border border-gray-100 transition-all duration-1000 ${isVisible ? "opacity-100 animate-slide-in-right" : "opacity-0"}`}
            >
              {isSubmitted ? (
                <div className="flex flex-col items-center justify-center py-8 text-center animate-scale-in">
                  <div className="bg-green-100 rounded-full p-3 mb-4">
                    <CheckCircle className="h-10 w-10 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2 text-gray-900">Thanks for signing up!</h3>
                  <p className="text-gray-600 mb-6">
                    We've sent a confirmation email to your inbox. You'll be the first to know when we launch.
                  </p>
                  <Button className="bg-primary hover:bg-primary/90 text-white">Back to home</Button>
                </div>
              ) : (
                <>
                  <h3 className="text-2xl font-bold mb-6 text-gray-900">Sign up for early access</h3>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-gray-700">
                        Full Name
                      </Label>
                      <Input
                        id="name"
                        placeholder="Enter your name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="rounded-lg border-gray-300 focus:border-primary focus:ring-primary"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-gray-700">
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="rounded-lg border-gray-300 focus:border-primary focus:ring-primary"
                        required
                      />
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-primary hover:bg-primary/90 text-white py-6 text-lg font-semibold rounded-lg mt-4 shadow-lg hover:shadow-primary/30 transition-all duration-300 hover:-translate-y-1"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Signing up..." : "Sign up now"}
                    </Button>
                    <p className="text-xs text-gray-500 text-center mt-4">
                      By signing up, you agree to our Terms of Service and Privacy Policy.
                    </p>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
